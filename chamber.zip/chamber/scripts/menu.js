// Responsive Menu
// const nav = document.querySelector("nav");
// const menuButton = document.querySelector("#MenuButton");

// menuButton.addEventListener("click", () => {
//     nav.classList.toggle("menuOpen");
// });